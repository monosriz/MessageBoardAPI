﻿using Microsoft.EntityFrameworkCore;
using Storytel.MessageBoard.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace Storytel.MessageBoard.Repository
{
    public class MessageRepository : IMessageRepository
    {

        private readonly MessageDBContext _context;

        public MessageRepository(MessageDBContext context)
        {
            _context = context;
        }
        public string  CreateMessage(Message Message, out bool Status)
        {
            try
            {
                Status = true;
                _context.Messages.Add(Message);
                _context.SaveChanges();
                return "Message Saved successfully." ;
            }
            catch (DbUpdateException ex)
            {
                Status = false;
                return "Fail to save. "+ex.Message;
            }
            
        }
        public string UpdateMessage(Message Message, out bool Status)
        {
            try
            {
                Status = true;
                Message messageItem = _context.Messages.Where(m => m.MessageID == Message.MessageID && m.PostedById == Message.PostedById).FirstOrDefault();
                if (messageItem != null)
                {
                    messageItem.Subject = Message.Subject;
                    messageItem.Text = Message.Text;
                    messageItem.DateUpdated = Message.DateUpdated;

                    _context.SaveChanges();
                    return "Message Updated successfully.";
                }
                else
                {
                    Status = false;
                    return "Message Not Found or You are not authorize to update this message.";
                }
                
                
            }
            catch (DbUpdateException ex)
            {
                Status = false;
                return "Fail to save. " + ex.Message;
            }


        }

        public string DeleteMessage(String PostedByID, Guid MessageID, out bool Status)
        {
            try
            {
                Status = true;
                Message messageItem = _context.Messages.Where(m => m.MessageID == MessageID && m.PostedById == PostedByID).FirstOrDefault();
                if (messageItem != null)
                {


                    _context.Messages.Remove(messageItem);
                    _context.SaveChanges();

                    return "Message Deleted successfully.";
                }
                else
                {
                    Status = false;
                    return "Message Not Found or you are not authorize to delete this message.";
                }

                
            }
                
            catch (DbUpdateException ex)
            {
                Status = false;
                return "Fail to Delete. " + ex.Message;
            }

        }

        public Message GetByID(Guid MessageID)
        {
            try
            {
               
                Message messageItem = _context.Messages.Where(m => m.MessageID == MessageID).FirstOrDefault();
                if (messageItem != null)
                {
                                        
                    return messageItem;
                }
                else
                {
                  
                    return null;
                }


            }

            catch (DbUpdateException ex)
            {
               
                return null;
            }

        }
        public List<Message> GetAllMessage()
        {
            return _context.Messages.ToList();
        }
    }
}
