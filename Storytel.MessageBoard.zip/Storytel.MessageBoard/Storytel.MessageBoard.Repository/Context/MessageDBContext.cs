﻿using Microsoft.EntityFrameworkCore;
using Storytel.MessageBoard.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Repository
{
   public class MessageDBContext:DbContext
    {
        public MessageDBContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<Message> Messages { get; set; }

    }

    
}
