﻿using Microsoft.AspNetCore.Mvc.Testing;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Xunit.Extensions.Ordering;
[assembly: CollectionBehavior(DisableTestParallelization = true)]
[assembly: TestCaseOrderer("Xunit.Extensions.Ordering.TestCaseOrderer", "Xunit.Extensions.Ordering")]
[assembly: TestCollectionOrderer("Xunit.Extensions.Ordering.CollectionOrderer", "Xunit.Extensions.Ordering")]

namespace Storytel.MessageBoard.XUnitTest
{
    
    
    public class TestMessageController : IClassFixture<WebApplicationFactory<WebApi.Startup>>
    {

        public HttpClient Client { get; }

        public static Guid MessageID{ get; set; }
        public TestMessageController(WebApplicationFactory<WebApi.Startup> fixture)
        {
            Client = fixture.CreateClient();
            Client.DefaultRequestHeaders.Add("UserID", "monosrizdutta@gmail.com");
        }



        

        /// <summary>
        /// Faile to add a new message due to misssing information.
        /// </summary>
        /// <returns></returns>
        [Fact, Order(1)]
        public async Task Add_InvalidObjectPassed()
        {


            var myObject = (dynamic)new JObject();
            myObject.Subject = "";
            myObject.Text = "What is the status?";

            var content = new StringContent(myObject.ToString(), Encoding.UTF8, "application/json");
            var response = await Client.PostAsync("api/Message/create", content);
            

            dynamic ResponseMessage = JObject.Parse(await response.Content.ReadAsStringAsync());

           
            Assert.False((bool)ResponseMessage.success, (string)ResponseMessage.message);


        }
        /// <summary>
        /// Add new message with correct information.
        /// </summary>
        /// <returns></returns>
        [Fact, Order(2)]
        public async Task Add_ValidObjectPassed()
        {

            
            var myObject = (dynamic)new JObject();
            myObject.Subject = "Status Message 1";
            myObject.Text = "What is the status of Task 1?";
            var content = new StringContent(myObject.ToString(), Encoding.UTF8, "application/json");

            var response = await Client.PostAsync("api/Message/create", content);
            dynamic ResponseMessage = JObject.Parse(await response.Content.ReadAsStringAsync());
            MessageID = (Guid)ResponseMessage.messageID;
            Assert.True((bool)ResponseMessage.success, (string)ResponseMessage.message);

        }
        /// <summary>
        /// Faile to return any message due to wrong GUID
        /// </summary>
        [Fact, Order(3)]
        public void GetByID_UnknownGuidPassed_ReturnsBadRequest()
        {
            var response = Client.GetAsync("api/Message/GetByID/"+Guid.NewGuid().ToString()).Result;

            Assert.Equal(response.StatusCode.ToString(), HttpStatusCode.BadRequest.ToString());
        }

        /// <summary>
        /// Return Ok response  for GET By ID call
        /// </summary>
        [Fact, Order(4)]
        public void GetByID_ExistingGuidPassed_ReturnsOkResult()
        {
            var response = Client.GetAsync("api/Message/GetByID/"+MessageID.ToString()).Result;

            Assert.Equal(response.StatusCode.ToString(), HttpStatusCode.OK.ToString());
        }

        /// <summary>
        /// Return Ok response  for GET ALl call 
        /// </summary>
        /// <returns></returns>
        [Fact, Order(5)]
        public void GetALL_WhenCalled_ReturnsOkResult()
        {
            
            var response =  Client.GetAsync("api/Message/GetAllMessages").Result;

            Assert.Equal(response.StatusCode.ToString(), HttpStatusCode.OK.ToString());
        }
        /// <summary>
        /// Return the colletion with one message
        /// </summary>
        /// <returns></returns>
        [Fact, Order(6)]
        public async Task GetAll_WhenCalled_ReturnsAllItems()
        {

            
            var response = await Client.GetAsync("api/Message/GetAllMessages");
            JArray ResponseMessages = JArray.Parse(await response.Content.ReadAsStringAsync());


            Assert.Equal(1, int.Parse(ResponseMessages.Count.ToString()));
        }
        /// <summary>
        /// Fail to update existing message due to wrong MessageID passed
        /// </summary>
        /// <returns></returns>
        [Fact, Order(7)]
        public async Task Update_InvalidObjectPassed()
        {

            
            var myObject = (dynamic)new JObject();

            myObject.messageID =Guid.NewGuid();
            myObject.Subject = "Status Message 1";
            myObject.Text = "What is the update?";

            var content = new StringContent(myObject.ToString(), Encoding.UTF8, "application/json");
            var response = await Client.PutAsync("api/Message/update", content);


            dynamic ResponseMessage = JObject.Parse(await response.Content.ReadAsStringAsync());


            Assert.False((bool)ResponseMessage.success, (string)ResponseMessage.message);


        }
        /// <summary>
        /// Update exisitng messgae
        /// </summary>
        /// <returns></returns>
        [Fact, Order(8)]
        public async Task Update_ValidObjectPassed()
        {
            

            var myObject = (dynamic)new JObject();

            myObject.messageID = MessageID;
            myObject.Subject = "Status Message 1";
            myObject.Text = "What is the update?";

            var content = new StringContent(myObject.ToString(), Encoding.UTF8, "application/json");
            var response = await Client.PutAsync("api/Message/update", content);


            dynamic ResponseMessage = JObject.Parse(await response.Content.ReadAsStringAsync());


            Assert.True((bool)ResponseMessage.success, (string)ResponseMessage.message);


        }
        /// <summary>
        /// Fail to delete message due to wrong MessageId.
        /// </summary>
        /// <returns></returns>
        [Fact, Order(9)]
        public async Task Remove_NotExistingGuidPassed_ReturnsFalseResponse()
        {
           
            
           
            var response = await Client.DeleteAsync("api/Message/delete/"+Guid.NewGuid().ToString());


            dynamic ResponseMessage = JObject.Parse(await response.Content.ReadAsStringAsync());


            Assert.False((bool)ResponseMessage.success, (string)ResponseMessage.message);

        }
        /// <summary>
        /// Deletion of MessageID
        /// </summary>
        /// <returns></returns>
        [Fact, Order(10)]
        public async Task Delete_ValidObjectPassed()
        {
           
                        
            var response = await Client.DeleteAsync("api/Message/delete/"+MessageID);


            dynamic ResponseMessage = JObject.Parse(await response.Content.ReadAsStringAsync());


            Assert.True((bool)ResponseMessage.success, (string)ResponseMessage.message);


        }
        /// <summary>
        /// Message does not exist, after deletion
        /// </summary>
        /// <returns></returns>
        [Fact, Order(11)]
        public void GetByID_AfterDeleteCalled_ReturnsBadResponse()
        {


            var response = Client.GetAsync("api/Message/GetByID/" + MessageID).Result;

            Assert.Equal(response.StatusCode.ToString(), HttpStatusCode.BadRequest.ToString());
        }
    }
    
}
