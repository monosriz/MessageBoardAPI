﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Model
{
    public interface IMessageRepository
    {

           string CreateMessage(Message Message, out bool Status);
           string UpdateMessage(Message Message, out bool Status);
           string DeleteMessage(String PostedByID, Guid MessageID, out bool Status);
           List<Message> GetAllMessage();
           Message GetByID(Guid MessageID);
    }
}
