﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Model
{
    public class Message
    {

        public Message(string subject, string text, 
     string postedById, DateTime datePosted, DateTime dateUpdated)
        {
            this.MessageID = Guid.NewGuid();
            this.Subject = subject;
            this.Text = text;
            
            this.PostedById = postedById;
            this.DatePosted = datePosted;
            this.DateUpdated = dateUpdated;
        }


        public Message(Guid messageid, string subject, string text,
    string postedById,  DateTime dateUpdated)
        {
            this.MessageID =messageid;
            this.Subject = subject;
            this.Text = text;
           
            this.PostedById = postedById;
          
            this.DateUpdated = dateUpdated;
        }


        public Guid MessageID
        { get;  set; }
        public string Subject
        { get;  set; }
        public string Text
        { get;  set; }

        public string PostedById
        { get;  set; }

        public DateTime DatePosted
        { get;  set; }

        public DateTime DateUpdated
        { get;  set; }


    }
}
