﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Model
{
   public class MessageService
    {
        private IMessageRepository _monarchRepository;

        public MessageService(IMessageRepository messageRepository)
        {

            _monarchRepository = messageRepository;
            
        }
        /// <summary>
        /// Create a Message
        /// </summary>
        /// <param name="Message"></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        public string CreateNewMessage(Message Message, out bool Status)
        {
            string strResponse = string.Empty;
            try
            {
                Status = true;
                if (Message != null)
                {
                    strResponse= _monarchRepository.CreateMessage(Message,out Status);
                }
                return strResponse;
            }

            catch (Exception ex)
            {
                Status = false;
                return ex.Message;
            }
        }

        /// <summary>
        /// Update a message
        /// </summary>
        /// <param name="Message"></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        public string UpdateMessage(Message Message, out bool Status)
        {
            string strResponse = string.Empty;
            try
            {
                Status = true;
                if (Message != null)
                {
                    strResponse=_monarchRepository.UpdateMessage(Message,out Status);
                }

                return strResponse;
            }

            catch (Exception ex)
            {
                Status = false;
                return ex.Message;
            }
        }
        /// <summary>
        /// Delete a Message
        /// </summary>
        /// <param name="PostedByID"></param>
        /// <param name="MessageID"></param>
        /// <param name="Status"></param>
        /// <returns></returns>
        public string DeleteMessage(String PostedByID,Guid MessageID, out bool Status)
        {
            string strResponse = string.Empty;
            Status = true;
            try
            {
                if (PostedByID != string.Empty || MessageID != null)
                {
                    strResponse = _monarchRepository.DeleteMessage(PostedByID, MessageID, out Status);
                }
                return strResponse;
            }
            catch (Exception ex)
            {
                Status = false;
                return ex.Message;
            }
        }
        /// <summary>
        /// Get All Message
        /// </summary>
        /// <returns></returns>
        public List<Message> GetAllMessage()
        {
            string strResponse = string.Empty;
            try
            {
                
                  return  _monarchRepository.GetAllMessage();
               
                
            }
            catch 
            {
                return null;
            }
        }

        /// <summary>
        /// Get All Message
        /// </summary>
        /// <returns></returns>
        public Message GetByID(Guid MeessageID)
        {
            
            try
            {

                return _monarchRepository.GetByID(MeessageID);


            }
            catch
            {
                return null;
            }
        }
    }
}
