﻿using Microsoft.AspNetCore.Mvc;
using Storytel.MessageBoard.Appservices;
using Storytel.MessageBoard.Appservices.Messages;
using Storytel.MessageBoard.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Storytel.MessageBoard.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessageController : ControllerBase
    {


        ApplicationMessageService _applicationMessageService;

        public MessageController(ApplicationMessageService applicationMonarchServic)
        {
            _applicationMessageService = applicationMonarchServic;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // Get api/<MeassageController>/GetByID/5764b04a-ef54-4e7e-9071-10b6ffad0731
        [HttpGet()]
        [Route("GetByID/{id}")]
        public IActionResult GetByID(Guid id)

        {

            if (Request.Headers.ContainsKey("UserID"))
            {

                var Message = _applicationMessageService.GetByID(id);
                if(Message!=null)
                      return Ok(Message);
                else
                    return BadRequest(new CreateReponse { Success = false, Message = "Message not found.", });
            }
            else
                return BadRequest(new CreateReponse { Success = false, Message = "UserID (Email ID) is mising from Header", });

        }

        /// <summary>
        /// Get All Message
        /// </summary>
        /// <returns></returns>
        // GET: api/<MeassageController>
        [HttpGet]
        [Route("GetAllMessages")]

        public IActionResult GetAllMessages()
        {
            if (Request.Headers.ContainsKey("UserID"))
            {
                return Ok(_applicationMessageService.GetAllMessage());
            }
            return BadRequest(new  { Success = false, Message = "UserID (Email ID) is mising from Header", });
        }




        /// <summary>
        /// Used to Add New Message Item
        /// </summary>        
        /// <param name="Message"></param>
        /// <returns></returns>
        // POST: api/SaveMessage
        [HttpPost()]
        [Route("Create")]
        public IActionResult Create([FromBody]  CreateRequest Message)

        {


            if (Request.Headers.ContainsKey("UserID"))
            {
                string Token = Request.Headers["UserID"].First();
                CreateReponse Response = _applicationMessageService.CreateMessage(Token, Message);
                return Ok(Response);
            }
            else
                return BadRequest(new CreateReponse { Success=false,   Message= "UserID (Email ID) is mising from Header", }) ;
          

        }

        /// <summary>
        ///Used to Update Message Item 
        /// </summary>
        /// <param name="Message"></param>
        /// <returns></returns>
        // Put: api/Update
        [HttpPut()]
        [Route("Update")]
        public IActionResult Update([FromBody] UpdateRequest Message)

        {
          
            if (Request.Headers.ContainsKey("UserID"))
            {
                string Token = Request.Headers["UserID"].First();
                UpdateResponse Response = _applicationMessageService.UpdateMessage(Token, Message);
                return Ok(Response);
            }
            else
                return BadRequest(new CreateReponse { Success = false, Message = "UserID (Email ID) is mising from Header", });

        }

        /// <summary>
        /// Used to delete a Message Item
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE api/<MeassageController>/Delete/5764b04a-ef54-4e7e-9071-10b6ffad0731
        [HttpDelete()]
        [Route("Delete/{id}")]
        public IActionResult Delete(Guid id)

        {
            
            if (Request.Headers.ContainsKey("UserID"))
            {
                string Token = Request.Headers["UserID"].First();
                DeleteResponse Response = _applicationMessageService.DeleteMessage(Token, id);
                return Ok(Response);
            }
            else
                return BadRequest(new CreateReponse { Success = false, Message = "UserID (Email ID) is mising from Header", });

        }


       
    }
}
