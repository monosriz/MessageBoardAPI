﻿using Storytel.MessageBoard.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Appservices.Messages
{
   public  class CreateReponse:ResponseBase
    {

        public Guid MessageID { get; set; }
        
        public string Subject
        { get;  set; }
        public string Text
        { get;  set; }

        public string PostedById
        { get;  set; }

        public DateTime DatePosted
        { get; internal set; }

        public DateTime DateUpdated
        { get;  set; }

    }
}
