﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Appservices.Messages
{
    public class CreateRequest
    {
        public string Subject
        { get;  set; }
        public string Text
        { get;  set; }
       
    }
}
