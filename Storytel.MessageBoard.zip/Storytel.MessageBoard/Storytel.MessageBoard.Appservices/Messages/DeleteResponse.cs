﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Appservices.Messages
{
   public class DeleteResponse:ResponseBase
    {
        public Guid MessageID { get; set; }
    }
}
