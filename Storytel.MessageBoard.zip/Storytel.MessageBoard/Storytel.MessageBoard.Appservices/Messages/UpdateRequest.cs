﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Appservices.Messages
{
   public class UpdateRequest
    {
        public string MessageID { get; set; }
        public string Subject
        { get; set; }
        public string Text
        { get; set; }

        
    }
}
