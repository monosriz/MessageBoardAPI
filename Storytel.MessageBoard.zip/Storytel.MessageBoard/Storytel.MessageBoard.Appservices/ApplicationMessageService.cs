﻿using Storytel.MessageBoard.Appservices.Messages;
using Storytel.MessageBoard.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Storytel.MessageBoard.Appservices
{
    public class ApplicationMessageService
    {
        private MessageService _messageService;

        public ApplicationMessageService(MessageService messageService)
        {
            _messageService = messageService;
        }
        /// <summary>
        /// Use this function to Ceate a New Message 
        /// </summary>
        /// <param name="PostedByID"></param>
        /// <param name="Message"></param>
        /// <returns></returns>
        public CreateReponse CreateMessage(String PostedByID,CreateRequest Message)
        {
            bool Status = true;
            var _reponse = new CreateReponse();
            try
            {
                if(Message.Subject.Trim()==string.Empty)
                {
                    _reponse.Success = false;
                    _reponse.Message = "Subject field can't be empty.";
                    return _reponse;

                }

                if (Message.Text.Trim() == string.Empty)
                {
                    _reponse.Success = false;
                    _reponse.Message = "Text field can't be empty.";
                    return _reponse;
                }

                var _message = new Message(Message.Subject, Message.Text, PostedByID, DateTime.Now.Date, DateTime.Now.Date);

                string strResult=_messageService.CreateNewMessage(_message,out Status);

                _reponse.Success = Status;
                _reponse.Message = strResult;
                _reponse.MessageID = _message.MessageID;
                _reponse.Subject = _message.Subject;
                _reponse.Text = _message.Text;
                _reponse.PostedById = _message.PostedById;
                _reponse.DatePosted = _message.DatePosted;
                _reponse.DateUpdated = _message.DateUpdated;





            }

            catch ( Exception ex)
            {
                _reponse.Success = false;
                _reponse.Message = "Failed -  " + ex.Message;
            }


            return _reponse;

        }
        /// <summary>
        /// Use this function to Update a message
        /// </summary>
        /// <param name="PostedByID"></param>
        /// <param name="Message"></param>
        /// <returns></returns>
        public UpdateResponse UpdateMessage(String PostedByID, UpdateRequest Message)
        {

            var _reponse = new UpdateResponse();
            bool Status = true;
            try
            {
                if (Message.Subject.Trim() == string.Empty)
                {
                    _reponse.Success = false;
                    _reponse.Message = "Subject field can't be empty.";
                    return _reponse;

                }

                if (Message.Text.Trim() == string.Empty)
                {
                    _reponse.Success = false;
                    _reponse.Message = "Text field can't be empty.";
                    return _reponse;
                }

                var _message = new Message(Guid.Parse( Message.MessageID), Message.Subject, Message.Text, PostedByID,  DateTime.Now.Date);

                string strResult = _messageService.UpdateMessage(_message, out Status);

                _reponse.Success = Status;
                _reponse.Message = strResult;
                _reponse.MessageID = _message.MessageID;
                _reponse.Subject = _message.Subject;
                _reponse.Text = _message.Text;
                _reponse.PostedById = _message.PostedById;
                _reponse.DatePosted = _message.DatePosted;
                _reponse.DateUpdated = _message.DateUpdated;





            }

            catch (Exception ex)
            {
                _reponse.Success = false;
                _reponse.Message = "Failed -  " + ex.Message;
            }


            return _reponse;

        }
        /// <summary>
        /// Use this function to delete a message
        /// </summary>
        /// <param name="PostedByID"></param>
        /// <param name="MessageID"></param>
        /// <returns></returns>
        public DeleteResponse DeleteMessage(String PostedByID, Guid  MessageID)
        {

            var _reponse = new DeleteResponse();
             bool Status = true;
            try
            {
                

              

                string strResult = _messageService.DeleteMessage(PostedByID, MessageID,out Status);

                _reponse.Success = Status;
                _reponse.Message = strResult;
                _reponse.MessageID =MessageID;
                




            }

            catch (Exception ex)
            {
                _reponse.Success = false;
                _reponse.Message = "Failed -  " + ex.Message;
            }


            return _reponse;

        }

       
        public Message GetByID(Guid MeessageID)
        {


            try
            {




                return _messageService.GetByID(MeessageID);







            }

            catch
            {
                return null;
            }




        }
        /// <summary>
        /// Use this function to get all Message
        /// </summary>
        /// <returns></returns>
        public List<Message>  GetAllMessage()
        {

          
            try
            {




               return _messageService.GetAllMessage();

               





            }

            catch             {
                return null;
            }


            

        }
    }
}
